# 📱 Pixel Gemini Offer Finder — Streamlit UI

Web-based replacement for the Telegram bot. Same automation engine, local browser UI.

## Prerequisites

| Requirement | Install |
|---|---|
| Python 3.10+ | [python.org](https://python.org) |
| Chromium | `sudo apt install chromium-browser chromium-chromedriver` |
| chromedriver | Bundled with `chromium-chromedriver` package |

## Quick start

```bash
# 1. Install deps
pip install -r requirements.txt

# 2. Run
streamlit run app.py
# → opens http://localhost:8501
```

Or use the launcher script:
```bash
chmod +x run.sh && ./run.sh
```

## Usage flow

1. **Enter email + password** in the login form
2. **(Optional)** Paste your TOTP secret key for automatic 2FA handling
3. Click **Start** — Streamlit launches headless Chrome simulating a Pixel 10 Pro
4. If the offer is found → you get a clickable activation link
5. If 2FA is required and you left the TOTP field blank → enter your 6-digit code manually

## Equivalent of Telegram commands

| Telegram `/command` | Streamlit equivalent |
|---|---|
| `/login` | Login form on first screen |
| `/check_offer` | Triggered automatically after login |
| `/get_link` | Displayed prominently on result screen |
| `/status` | Sidebar + device expander on result screen |
| `/logout` | "Logout & Start Over" button |

## Notes

- Credentials are stored **in memory only** for the session duration
- Up to 3 retry attempts with a new device profile each time
- Rate limit: use the "Try Again" button instead of rapid manual refreshes
