"""
Streamlit UI — Pixel 10 Pro · Google One Gemini Pro Offer Finder
Playwright edition: proxy rotation, live fingerprint log, Codespaces-ready.
"""

import os
import re
import sys
import time
import uuid
from typing import Optional

import streamlit as st

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)

import config
from device_simulator import create_device_profile, DeviceProfile, PIXEL_10_PRO_SPECS
from proxy_manager import parse_proxy_list, select_valid_proxy
from google_automation import (
    GoogleAutomationError,
    start_login,
    submit_2fa_code as _submit_2fa,
    check_offer_with_driver,
    close_driver,
    STEALTH_AVAILABLE,
)

# ── Page config ───────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Pixel Gemini Finder",
    page_icon="📱",
    layout="centered",
    initial_sidebar_state="collapsed",
)

# ── CSS ───────────────────────────────────────────────────────────────────────
st.markdown("""
<style>
.main .block-container { max-width: 700px; padding-top: 2.5rem; }

.offer-card {
    background: linear-gradient(135deg, #1a73e8 0%, #0d47a1 100%);
    border-radius: 14px; padding: 1.6rem 1.8rem 1.4rem;
    color: #fff; margin: 1rem 0 1.4rem;
    box-shadow: 0 4px 18px rgba(26,115,232,.35);
}
.offer-card h3 { margin: 0 0 .4rem; font-size: 1.15rem; }
.offer-link-box {
    background: rgba(255,255,255,.18); border-radius: 8px;
    padding: .65rem 1rem; font-family: monospace; word-break: break-all;
    font-size: .82rem; margin: .6rem 0 1.1rem;
}
.open-btn {
    display: inline-block; background: #fff; color: #1a73e8 !important;
    font-weight: 700; border-radius: 8px; padding: .5rem 1.2rem;
    text-decoration: none !important; font-size: .92rem;
}
.log-pre {
    background: #0e1117; color: #a8d8a8; border-radius: 8px;
    padding: .85rem 1rem; font-family: monospace; font-size: .75rem;
    line-height: 1.6; max-height: 340px; overflow-y: auto;
    white-space: pre-wrap; word-break: break-word;
}
</style>
""", unsafe_allow_html=True)

# ── Global driver store (persists across Streamlit reruns for 2FA) ─────────
_DRIVER_STORE: dict[str, object] = {}
MAX_ATTEMPTS = 3


# ═══════════════════════════════════════════════════════════════════════════════
# State helpers
# ═══════════════════════════════════════════════════════════════════════════════

def _sid() -> str:
    if "sid" not in st.session_state:
        st.session_state.sid = str(uuid.uuid4())
    return st.session_state.sid

def _stage() -> str:
    return st.session_state.get("stage", "login")

def _set_stage(s: str):
    st.session_state.stage = s

def _add_log(msg: str, holder=None):
    if "logs" not in st.session_state:
        st.session_state.logs = []
    st.session_state.logs.append(msg)
    if holder is not None:
        _refresh_log(holder)

def _refresh_log(holder):
    lines = "\n".join(st.session_state.get("logs", []))
    holder.markdown(f'<div class="log-pre">{lines}</div>', unsafe_allow_html=True)

def _clear_session():
    drv = _DRIVER_STORE.pop(_sid(), None)
    close_driver(drv)
    for k in list(st.session_state.keys()):
        del st.session_state[k]


# ═══════════════════════════════════════════════════════════════════════════════
# Fingerprint report logger
# ═══════════════════════════════════════════════════════════════════════════════

def _log_fingerprint(
    device: DeviceProfile,
    proxy_info: Optional[dict] = None,
    cookies_count: Optional[int] = None,
    holder=None,
):
    S = PIXEL_10_PRO_SPECS
    ua_short = device.user_agent[:72] + "…" if len(device.user_agent) > 75 else device.user_agent
    stealth_status = "✅ active" if STEALTH_AVAILABLE else "❌ not installed (pip install playwright-stealth)"

    lines = [
        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
        "📱  FINGERPRINT REPORT",
        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
        f"  Model         {device.model}",
        f"  Android       {device.android_version}  (SDK {device.android_sdk})",
        f"  Build ID      {device.build_id}",
        f"  Chrome        {device.chrome_version}",
        f"  IMEI          {device.imei[:8]}…",
        f"  Android ID    {device.android_id}",
        f"  User-Agent    {ua_short}",
        "",
        "  STEALTH ENGINE",
        f"    playwright-stealth  {stealth_status}",
        f"    WebGL vendor        {S['webgl_vendor']}",
        f"    WebGL renderer      {S['webgl_renderer']}",
        f"    Platform            {S['platform']}",
        f"    Touch points        {S['max_touch_points']}",
        f"    Device memory       {S['device_memory']} GB",
        f"    Hardware cores      {S['hardware_concurrency']}",
        f"    Mobile UA           ✅",
        f"    Headless            ✅",
    ]

    if cookies_count is not None:
        ok = "✅" if cookies_count > 0 else "❌"
        lines.append(f"    Session cookies     {cookies_count} {ok}")

    if proxy_info and proxy_info.get("query"):
        ip     = proxy_info.get("query", "?")
        city   = proxy_info.get("city", "?")
        region = proxy_info.get("regionName", "?")
        isp    = proxy_info.get("isp", "?")
        ptype  = "🏢 Datacenter" if proxy_info.get("hosting") else "🏠 Residential"
        lines += [
            "",
            "  PROXY",
            f"    IP          {ip}",
            f"    Location    {city}, {region}  US",
            f"    ISP         {isp}",
            f"    Type        {ptype}",
        ]
    else:
        lines += ["", "  PROXY     direct connection (no proxy)"]

    lines.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")

    for line in lines:
        _add_log(line, holder)


# ═══════════════════════════════════════════════════════════════════════════════
# Core automation
# ═══════════════════════════════════════════════════════════════════════════════

def _run_automation(
    email: str,
    password: str,
    totp_secret: str,
    proxy_list: list,
    log_holder,
) -> tuple:
    """Returns (offer_link, status, error_msg). status: found|not_found|needs_2fa|error"""
    _id = _sid()

    # ── Proxy selection ───────────────────────────────────────────────────────
    selected_proxy: Optional[str] = None
    proxy_info: dict = {}

    if proxy_list:
        working = list(proxy_list)          # copy — select_valid_proxy mutates in-place
        _add_log("🌐 Selecting proxy from pool…", log_holder)
        selected_proxy, proxy_info = select_valid_proxy(
            working,
            log_cb=lambda m: _add_log(m, log_holder),
        )
        st.session_state.proxy_info = proxy_info
        if not selected_proxy:
            _add_log("⚠️  No valid US proxy found — proceeding direct (geo-restriction may apply)", log_holder)
    else:
        _add_log("ℹ️  No proxies configured — direct connection", log_holder)

    # ── Retry loop ────────────────────────────────────────────────────────────
    for attempt in range(1, MAX_ATTEMPTS + 1):
        _add_log(f"\n🔧  [{attempt}/{MAX_ATTEMPTS}]  Generating Pixel 10 Pro device profile…", log_holder)
        device = create_device_profile()
        st.session_state.device = device

        _log_fingerprint(device, proxy_info=proxy_info or None, holder=log_holder)

        driver = None
        try:
            _add_log("🚀  Launching headless Chromium via Playwright…", log_holder)
            driver, login_status = start_login(email, password, device, proxy=selected_proxy)

            if login_status == "needs_totp":
                if totp_secret:
                    try:
                        import pyotp
                        code = pyotp.TOTP(totp_secret).now()
                        _add_log("🔑  Auto-generating TOTP code…", log_holder)
                        accepted = _submit_2fa(driver, code)
                        if not accepted:
                            close_driver(driver)
                            return None, "error", "Auto-TOTP rejected — check your secret key."
                        _add_log("✅  2FA passed automatically!", log_holder)
                    except ImportError:
                        close_driver(driver)
                        return None, "error", "pyotp not installed — run: pip install pyotp"
                    except Exception as exc:
                        close_driver(driver)
                        return None, "error", f"Auto-TOTP error: {exc}"
                else:
                    _DRIVER_STORE[_id] = driver
                    _add_log("🔐  Manual 2FA required — waiting for code…", log_holder)
                    return None, "needs_2fa", None

            elif login_status != "success":
                close_driver(driver)
                return None, "error", "Login failed — check credentials or account status."

            _add_log("✅  Login successful!", log_holder)

            # Cookie count
            try:
                cookies = driver.context.cookies()
                _add_log(f"🍪  Session cookies: {len(cookies)}", log_holder)
            except Exception:
                pass

            _add_log("🔍  Navigating to Google One…", log_holder)
            offer_link = check_offer_with_driver(driver)
            close_driver(driver)
            driver = None

            if offer_link:
                _add_log("🎉  Offer link found!", log_holder)
                return offer_link, "found", None

            _add_log(f"😔  Attempt {attempt}: no offer detected.", log_holder)
            if attempt < MAX_ATTEMPTS:
                _add_log(f"⏳  Waiting 12 s before retry with fresh device profile…", log_holder)
                time.sleep(12)

        except GoogleAutomationError as exc:
            if driver:
                close_driver(driver)
            return None, "error", str(exc)
        except Exception as exc:
            if driver:
                close_driver(driver)
            return None, "error", f"Unexpected error: {exc}"

    return None, "not_found", None


# ═══════════════════════════════════════════════════════════════════════════════
# Stage renderers
# ═══════════════════════════════════════════════════════════════════════════════

def _render_login():
    st.markdown("### 🔐 Sign in with Google")
    st.markdown("""
    <div style="display:flex;flex-direction:column;gap:.35rem;margin-bottom:1rem;">
      <div>📱 &nbsp;<span style="font-size:.9rem">Simulates a <b>Pixel 10 Pro</b> (Android 16) device</span></div>
      <div>🛡️ &nbsp;<span style="font-size:.9rem">playwright-stealth + custom JS fingerprint injection</span></div>
      <div>💎 &nbsp;<span style="font-size:.9rem">Scans Google One for the <b>12-month free Gemini Advanced</b> offer</span></div>
    </div>
    """, unsafe_allow_html=True)
    st.divider()

    with st.form("login_form", clear_on_submit=False):
        email = st.text_input("📧 Google account email", placeholder="you@gmail.com")
        password = st.text_input("🔒 Password", type="password")
        totp_secret = st.text_input(
            "🔑 TOTP secret key *(optional — auto-handles 2FA)*",
            placeholder="JBSWY3DPEHPK3PXP",
            help="Base32 secret from your authenticator app. Found when adding the account to Google Authenticator (the QR code encodes it). Leave blank to enter the 6-digit code manually.",
        )

        # ── Proxy section ─────────────────────────────────────────────────
        st.markdown("---")
        with st.expander("🌐 Proxy Settings *(optional)*"):
            st.caption(
                "One proxy per line.  "
                "Supports `http://ip:port`, `socks5://ip:port`, "
                "or with credentials: `http://ip:port|user:pass`"
            )
            proxy_raw = st.text_area(
                "Proxy list",
                placeholder=(
                    "http://1.2.3.4:8080\n"
                    "socks5://5.6.7.8:1080\n"
                    "http://9.10.11.12:3128"
                ),
                height=110,
                label_visibility="collapsed",
            )
            st.warning(
                "⚠️ Free public proxies may log your traffic. "
                "Your Google credentials pass through the proxy — "
                "use trusted proxies or leave blank.",
                icon="⚠️",
            )

        st.caption("Credentials are held in memory only — never written to disk.")
        submitted = st.form_submit_button(
            "🚀  Start — Simulate Device & Find Offer",
            use_container_width=True,
            type="primary",
        )

    if submitted:
        if not re.match(r'^[\w.+-]+@[\w.-]+\.[a-zA-Z]{2,}$', email.strip(), re.I):
            st.error("⚠️ Please enter a valid email address.")
            return
        if not password:
            st.error("⚠️ Password is required.")
            return

        proxy_list = parse_proxy_list(proxy_raw) if proxy_raw.strip() else []

        st.session_state.update({
            "email":        email.strip(),
            "password":     password,
            "totp_secret":  totp_secret.strip(),
            "proxy_list":   proxy_list,
            "logs":         [],
            "offer_link":   None,
            "error":        None,
            "device":       None,
            "proxy_info":   {},
        })
        _set_stage("run")
        st.rerun()


def _render_run():
    st.markdown("### ⚙️ Running Automation")
    st.caption("Keep this tab open — Playwright is driving a headless browser.")
    log_holder = st.empty()

    _set_stage("processing")   # guard against accidental re-run

    email       = st.session_state.get("email", "")
    password    = st.session_state.get("password", "")
    totp        = st.session_state.get("totp_secret", "")
    proxy_list  = st.session_state.get("proxy_list", [])

    try:
        with st.spinner("Playwright running… up to 90 seconds per attempt."):
            offer_link, status, error_msg = _run_automation(
                email, password, totp, proxy_list, log_holder,
            )
    except Exception as exc:
        drv = _DRIVER_STORE.pop(_sid(), None)
        close_driver(drv)
        st.session_state.error = f"Fatal: {exc}"
        _set_stage("result")
        st.rerun()
        return

    st.session_state.offer_link = offer_link
    st.session_state.error      = error_msg
    _set_stage("needs_2fa" if status == "needs_2fa" else "result")
    st.rerun()


def _render_processing():
    st.markdown("### ⏳ Automation In Progress")
    st.info("A session is already running. Refresh the page to start over.", icon="⏳")
    logs = st.session_state.get("logs", [])
    if logs:
        holder = st.empty()
        _refresh_log(holder)


def _render_needs_2fa():
    st.markdown("### 🔐 Two-Factor Authentication Required")
    st.warning(
        "Google is asking for your 2FA code. Open your authenticator app and enter "
        "the 6-digit code below. You have ~30 seconds before it expires.",
        icon="🔐",
    )

    # Show log so far
    logs = st.session_state.get("logs", [])
    if logs:
        with st.expander("📋 Activity so far", expanded=False):
            holder = st.empty()
            _refresh_log(holder)

    st.divider()

    with st.form("2fa_form"):
        code = st.text_input(
            "Authenticator code",
            placeholder="123456",
            max_chars=6,
            help="6-digit one-time code from Google Authenticator, Authy, etc.",
        )
        col1, col2 = st.columns([3, 1])
        with col1:
            ok = st.form_submit_button("✅ Submit Code", use_container_width=True, type="primary")
        with col2:
            cancel = st.form_submit_button("✖ Cancel", use_container_width=True)

    if cancel:
        drv = _DRIVER_STORE.pop(_sid(), None)
        close_driver(drv)
        _set_stage("login")
        st.rerun()

    if ok:
        if not (code.isdigit() and len(code) == 6):
            st.error("⚠️ Please enter exactly 6 digits.")
            return

        _id  = _sid()
        drv = _DRIVER_STORE.get(_id)
        if not drv:
            st.error("⚠️ Browser session expired — please start over.")
            _set_stage("login")
            st.rerun()
            return

        log_holder = st.empty()
        _add_log("🔄 Submitting 2FA code…", log_holder)

        with st.spinner("Verifying code…"):
            try:
                accepted = _submit_2fa(drv, code)
                if not accepted:
                    _DRIVER_STORE.pop(_id, None)
                    close_driver(drv)
                    st.session_state.error = "2FA code rejected — please start over."
                    _set_stage("result")
                else:
                    _add_log("✅ 2FA accepted! Checking Google One…", log_holder)
                    offer_link = check_offer_with_driver(drv)
                    _DRIVER_STORE.pop(_id, None)
                    close_driver(drv)
                    st.session_state.offer_link = offer_link
                    _set_stage("result")
            except Exception as exc:
                _DRIVER_STORE.pop(_id, None)
                close_driver(drv)
                st.session_state.error = str(exc)
                _set_stage("result")
        st.rerun()


def _render_result():
    offer_link  = st.session_state.get("offer_link")
    error       = st.session_state.get("error")
    device: Optional[DeviceProfile] = st.session_state.get("device")
    proxy_info  = st.session_state.get("proxy_info", {})

    # ── Success ───────────────────────────────────────────────────────────────
    if offer_link:
        safe = offer_link.replace("'", "%27")
        st.markdown(f"""
        <div class="offer-card">
          <h3>🎉 Gemini Advanced Offer Found!</h3>
          <p style="opacity:.85;font-size:.9rem;margin:.3rem 0 .5rem">
            Click below to activate your 12-month free Gemini Advanced subscription:
          </p>
          <div class="offer-link-box">{offer_link}</div>
          <a class="open-btn" href="{safe}" target="_blank" rel="noopener">
            🔗 Open Activation Link ↗
          </a>
        </div>
        """, unsafe_allow_html=True)
        st.text_input("Copy link:", value=offer_link, disabled=True, label_visibility="visible")

    # ── Failure ───────────────────────────────────────────────────────────────
    else:
        st.error(f"❌ {error or 'No active offer detected.'}")
        if not error or "credential" not in error.lower():
            with st.expander("Why might there be no offer?"):
                st.markdown("""
                - **Region** — Offer is US-only. Use a US proxy if you're outside the US.
                - **Already redeemed** — Offer was activated on this account previously.
                - **Active subscription** — Account already has Gemini Pro / Advanced.
                - **Family group** — A family member may have an active subscription.
                - **New account** — Very new accounts are sometimes rate-limited.
                - **Device not accepted** — Try clicking **Try Again** for a new fingerprint.
                """)

    # ── Activity log ─────────────────────────────────────────────────────────
    logs = st.session_state.get("logs", [])
    if logs:
        with st.expander("📋 Full Activity Log", expanded=not bool(offer_link)):
            holder = st.empty()
            _refresh_log(holder)

    # ── Device + proxy info ───────────────────────────────────────────────────
    if device:
        with st.expander("📱 Device Profile & Fingerprint"):
            S = PIXEL_10_PRO_SPECS
            st.json({
                "model":            device.model,
                "android_version":  device.android_version,
                "android_sdk":      device.android_sdk,
                "build_id":         device.build_id,
                "chrome_version":   device.chrome_version,
                "imei_prefix":      device.imei[:8] + "…",
                "android_id":       device.android_id,
                "stealth_active":   STEALTH_AVAILABLE,
                "webgl_vendor":     S["webgl_vendor"],
                "webgl_renderer":   S["webgl_renderer"],
                "platform":         S["platform"],
                "device_memory_gb": S["device_memory"],
                "hardware_cores":   S["hardware_concurrency"],
                "is_mobile":        True,
            })

    if proxy_info and proxy_info.get("query"):
        with st.expander("🌐 Proxy Used"):
            st.json({
                "ip":       proxy_info.get("query"),
                "city":     proxy_info.get("city"),
                "region":   proxy_info.get("regionName"),
                "country":  proxy_info.get("country"),
                "isp":      proxy_info.get("isp"),
                "hosting":  proxy_info.get("hosting"),
            })

    st.divider()
    col1, col2 = st.columns(2)
    with col1:
        label = "🔄 Try Again (New Device)" if not offer_link else "🔄 Check Again"
        if st.button(label, use_container_width=True, type="primary" if not offer_link else "secondary"):
            st.session_state.update({
                "logs": [], "offer_link": None, "error": None,
                "device": None, "proxy_info": {},
            })
            _set_stage("run")
            st.rerun()
    with col2:
        if st.button("🔒 Logout & Start Over", use_container_width=True):
            _clear_session()
            st.rerun()


# ═══════════════════════════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    _sid()

    st.markdown("## 📱 Pixel Gemini Offer Finder")
    st.caption("Pixel 10 Pro  ·  Android 16  ·  Playwright  ·  Google One 12-Month Gemini Advanced")

    with st.sidebar:
        st.markdown("### Session")
        email = st.session_state.get("email")
        if email:
            st.success(f"**{email}**", icon="✅")
            d = st.session_state.get("device")
            if d:
                st.caption(
                    f"Model: {d.model}  \n"
                    f"Android: {d.android_version}  \n"
                    f"Chrome: {d.chrome_version}"
                )
            proxy_info = st.session_state.get("proxy_info", {})
            if proxy_info.get("query"):
                st.caption(f"Proxy IP: {proxy_info['query']} 🇺🇸")
        else:
            st.info("Not signed in", icon="🔐")

        st.divider()
        st.caption(
            f"playwright-stealth: {'✅' if STEALTH_AVAILABLE else '❌ not installed'}  \n"
            "Credentials: memory only"
        )

        st.divider()
        with st.expander("🖥️ Codespaces setup"):
            st.code(
                "# In Codespaces terminal:\n"
                "pip install -r requirements.txt\n"
                "playwright install chromium --with-deps\n"
                "streamlit run app.py",
                language="bash",
            )

    st.divider()

    s = _stage()
    if   s == "login":      _render_login()
    elif s == "run":        _render_run()
    elif s == "processing": _render_processing()
    elif s == "needs_2fa":  _render_needs_2fa()
    elif s == "result":     _render_result()
    else:
        _set_stage("login")
        st.rerun()


if __name__ == "__main__":
    main()
