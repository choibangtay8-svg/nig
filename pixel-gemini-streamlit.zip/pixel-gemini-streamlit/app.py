"""
Streamlit UI — Pixel 10 Pro · Google One Gemini Pro Offer Finder
Drop-in replacement for the Telegram bot. Run with: streamlit run app.py
"""

import os
import re
import sys
import time
import uuid
import logging
from typing import Optional

import streamlit as st

# ── path setup ────────────────────────────────────────────────────────────────
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)

import config  # noqa: E402
from device_simulator import create_device_profile, DeviceProfile  # noqa: E402
from google_automation import (  # noqa: E402
    GoogleAutomationError,
    start_login,
    submit_2fa_code as _submit_2fa,
    check_offer_with_driver,
    close_driver,
)

# ── page config ───────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Pixel Gemini Finder",
    page_icon="📱",
    layout="centered",
    initial_sidebar_state="collapsed",
)

# ── CSS ───────────────────────────────────────────────────────────────────────
st.markdown("""
<style>
/* centre & max-width */
.main .block-container { max-width: 680px; padding-top: 2.5rem; }

/* success card */
.offer-card {
    background: linear-gradient(135deg, #1a73e8 0%, #0d47a1 100%);
    border-radius: 14px;
    padding: 1.6rem 1.8rem 1.4rem;
    color: #fff;
    margin: 1rem 0 1.4rem;
    box-shadow: 0 4px 18px rgba(26,115,232,.35);
}
.offer-card h3 { margin: 0 0 .4rem; font-size: 1.15rem; }
.offer-link-box {
    background: rgba(255,255,255,.18);
    border-radius: 8px;
    padding: .65rem 1rem;
    font-family: monospace;
    word-break: break-all;
    font-size: .82rem;
    margin: .6rem 0 1.1rem;
}
.open-btn {
    display: inline-block;
    background: #fff;
    color: #1a73e8 !important;
    font-weight: 700;
    border-radius: 8px;
    padding: .5rem 1.2rem;
    text-decoration: none !important;
    font-size: .92rem;
    transition: opacity .15s;
}
.open-btn:hover { opacity: .88; }

/* step badge */
.step-row { display: flex; align-items: center; gap: .55rem; margin: .25rem 0; }
.step-icon { font-size: 1.05rem; }
.step-text { font-size: .88rem; color: #555; }

/* log area */
.log-pre {
    background: #0e1117;
    color: #a8d8a8;
    border-radius: 8px;
    padding: .85rem 1rem;
    font-family: monospace;
    font-size: .78rem;
    line-height: 1.55;
    max-height: 280px;
    overflow-y: auto;
    white-space: pre-wrap;
    word-break: break-word;
}
</style>
""", unsafe_allow_html=True)

# ── global driver store (persists across Streamlit reruns for 2FA) ────────────
_DRIVER_STORE: dict[str, object] = {}
MAX_ATTEMPTS = 3


# ═══════════════════════════════════════════════════════════════════════════════
# State helpers
# ═══════════════════════════════════════════════════════════════════════════════

def _sid() -> str:
    if "sid" not in st.session_state:
        st.session_state.sid = str(uuid.uuid4())
    return st.session_state.sid


def _stage() -> str:
    return st.session_state.get("stage", "login")


def _set_stage(s: str):
    st.session_state.stage = s


def _add_log(msg: str, holder=None):
    ts = time.strftime("%H:%M:%S")
    entry = f"[{ts}] {msg}"
    if "logs" not in st.session_state:
        st.session_state.logs = []
    st.session_state.logs.append(entry)
    if holder is not None:
        _render_log_box(holder)


def _render_log_box(holder):
    lines = "\n".join(st.session_state.get("logs", []))
    holder.markdown(
        f'<div class="log-pre">{lines}</div>',
        unsafe_allow_html=True,
    )


def _clear_session():
    drv = _DRIVER_STORE.pop(_sid(), None)
    close_driver(drv)
    for k in list(st.session_state.keys()):
        del st.session_state[k]


# ═══════════════════════════════════════════════════════════════════════════════
# Core automation (blocking — runs in Streamlit's script thread)
# ═══════════════════════════════════════════════════════════════════════════════

def _run_automation(email: str, password: str, totp_secret: str, log_holder) -> tuple:
    """
    Returns (offer_link, status, error_msg)
    status: "found" | "not_found" | "needs_2fa" | "error"
    """
    _id = _sid()

    for attempt in range(1, MAX_ATTEMPTS + 1):
        _add_log(f"🔧 [{attempt}/{MAX_ATTEMPTS}] Generating fresh Pixel 10 Pro profile…", log_holder)
        device = create_device_profile()
        st.session_state.device = device

        driver = None
        try:
            _add_log("🌐 Starting headless Chrome & logging in…", log_holder)
            driver, login_status = start_login(email, password, device)

            if login_status == "needs_totp":
                if totp_secret:
                    try:
                        import pyotp  # optional dep
                        code = pyotp.TOTP(totp_secret).now()
                        _add_log("🔑 Auto-generating TOTP code…", log_holder)
                        accepted = _submit_2fa(driver, code)
                        if not accepted:
                            close_driver(driver)
                            return None, "error", "Auto-TOTP rejected — double-check your secret key."
                        _add_log("✅ 2FA passed automatically!", log_holder)
                    except ImportError:
                        close_driver(driver)
                        return None, "error", "pyotp not installed. Run: pip install pyotp"
                    except Exception as exc:
                        close_driver(driver)
                        return None, "error", f"Auto-TOTP error: {exc}"
                else:
                    # Manual 2FA — stash driver and return
                    _DRIVER_STORE[_id] = driver
                    _add_log("🔐 Manual 2FA required — waiting for your code…", log_holder)
                    return None, "needs_2fa", None

            _add_log("✅ Login OK! Navigating to Google One…", log_holder)
            offer_link = check_offer_with_driver(driver)
            close_driver(driver)
            driver = None

            if offer_link:
                _add_log("🎉 Offer link found!", log_holder)
                return offer_link, "found", None

            _add_log(f"😔 Attempt {attempt}: no offer detected.", log_holder)
            if attempt < MAX_ATTEMPTS:
                _add_log(f"⏳ Waiting 12 s before next attempt…", log_holder)
                time.sleep(12)

        except GoogleAutomationError as exc:
            if driver:
                close_driver(driver)
            return None, "error", str(exc)
        except Exception as exc:
            if driver:
                close_driver(driver)
            return None, "error", f"Unexpected error: {exc}"

    return None, "not_found", None


# ═══════════════════════════════════════════════════════════════════════════════
# Stage renderers
# ═══════════════════════════════════════════════════════════════════════════════

def _render_login():
    st.markdown("### 🔐 Sign in with Google")

    st.markdown("""
    <div class="step-row"><span class="step-icon">📱</span>
        <span class="step-text">Simulates a real <b>Pixel 10 Pro</b> (Android 16) device</span></div>
    <div class="step-row"><span class="step-icon">🤖</span>
        <span class="step-text">Headless Chrome logs into your Google account</span></div>
    <div class="step-row"><span class="step-icon">💎</span>
        <span class="step-text">Searches Google One for the <b>12-month free Gemini Pro</b> offer</span></div>
    """, unsafe_allow_html=True)

    st.divider()

    with st.form("login_form", clear_on_submit=False):
        email = st.text_input(
            "📧 Google account email",
            placeholder="you@gmail.com",
            autocomplete="email",
        )
        password = st.text_input(
            "🔒 Password",
            type="password",
            placeholder="Your Google password",
        )
        totp_secret = st.text_input(
            "🔑 TOTP secret key  *(optional — for automatic 2FA)*",
            placeholder="e.g. JBSWY3DPEHPK3PXP",
            help=(
                "If you have 2-step verification (authenticator app) enabled, "
                "paste the **base32 secret key** here and 2FA will be handled automatically. "
                "You can find the secret key when adding an account to your authenticator app "
                "(the QR code encodes it). Leave blank to enter the 6-digit code manually."
            ),
        )
        st.caption(
            "⚠️ Credentials are held in memory for this session only — never written to disk. "
            "Use only on accounts you own."
        )
        submitted = st.form_submit_button(
            "🚀  Start — Simulate Device & Find Offer",
            use_container_width=True,
            type="primary",
        )

    if submitted:
        if not re.match(r'^[\w.+-]+@[\w.-]+\.[a-zA-Z]{2,}$', email.strip(), re.IGNORECASE):
            st.error("⚠️ Please enter a valid email address.")
            return
        if not password:
            st.error("⚠️ Password is required.")
            return

        st.session_state.update({
            "email": email.strip(),
            "password": password,
            "totp_secret": totp_secret.strip(),
            "logs": [],
            "offer_link": None,
            "error": None,
            "device": None,
        })
        _set_stage("run")
        st.rerun()


def _render_run():
    """Execute automation; blocks until complete, then transitions to next stage."""
    st.markdown("### ⚙️ Running Automation")
    st.caption("Do not close or refresh this tab while Chrome is running.")

    log_holder = st.empty()
    _set_stage("processing")  # guard against accidental double-run

    email    = st.session_state.get("email", "")
    password = st.session_state.get("password", "")
    totp     = st.session_state.get("totp_secret", "")

    try:
        with st.spinner("Headless Chrome is running… this may take up to 90 seconds."):
            offer_link, status, error_msg = _run_automation(email, password, totp, log_holder)
    except Exception as exc:
        # Safety net
        drv = _DRIVER_STORE.pop(_sid(), None)
        close_driver(drv)
        st.session_state.error = f"Fatal: {exc}"
        _set_stage("result")
        st.rerun()
        return

    st.session_state.offer_link = offer_link
    st.session_state.error      = error_msg

    if status == "needs_2fa":
        _set_stage("needs_2fa")
    else:
        _set_stage("result")

    st.rerun()


def _render_processing():
    st.markdown("### ⏳ Already Running")
    st.info(
        "An automation session is in progress. "
        "If you need to restart, refresh the page.",
        icon="⏳",
    )
    logs = st.session_state.get("logs", [])
    if logs:
        holder = st.empty()
        _render_log_box(holder)


def _render_needs_2fa():
    st.markdown("### 🔐 Two-Factor Authentication Required")
    st.warning(
        "Your account has 2FA enabled. Please open your authenticator app and enter the 6-digit code below.",
        icon="🔐",
    )

    with st.form("2fa_form"):
        code = st.text_input(
            "Authenticator code",
            placeholder="123456",
            max_chars=6,
            help="6-digit one-time code from Google Authenticator, Authy, etc.",
        )
        col1, col2 = st.columns([3, 1])
        with col1:
            ok = st.form_submit_button("✅ Submit Code", use_container_width=True, type="primary")
        with col2:
            cancel = st.form_submit_button("✖ Cancel", use_container_width=True)

    if cancel:
        drv = _DRIVER_STORE.pop(_sid(), None)
        close_driver(drv)
        _set_stage("login")
        st.rerun()

    if ok:
        if not (code.isdigit() and len(code) == 6):
            st.error("⚠️ Please enter exactly 6 digits.")
            return

        _id  = _sid()
        drv = _DRIVER_STORE.get(_id)

        if not drv:
            st.error("⚠️ Session expired — the Chrome window was closed. Please start over.")
            _set_stage("login")
            st.rerun()
            return

        log_holder = st.empty()
        _add_log("🔄 Submitting 2FA code…", log_holder)

        with st.spinner("Verifying code…"):
            try:
                accepted = _submit_2fa(drv, code)
                if not accepted:
                    _DRIVER_STORE.pop(_id, None)
                    close_driver(drv)
                    st.session_state.error = "2FA code was rejected. Please start over."
                    _set_stage("result")
                else:
                    _add_log("✅ 2FA accepted! Checking Google One…", log_holder)
                    offer_link = check_offer_with_driver(drv)
                    _DRIVER_STORE.pop(_id, None)
                    close_driver(drv)
                    st.session_state.offer_link = offer_link
                    _set_stage("result")
            except Exception as exc:
                _DRIVER_STORE.pop(_id, None)
                close_driver(drv)
                st.session_state.error = str(exc)
                _set_stage("result")

        st.rerun()


def _render_result():
    offer_link = st.session_state.get("offer_link")
    error      = st.session_state.get("error")
    device: Optional[DeviceProfile] = st.session_state.get("device")

    # ── Success ───────────────────────────────────────────────────────────────
    if offer_link:
        safe_link = offer_link.replace("'", "%27")
        st.markdown(f"""
        <div class="offer-card">
            <h3>🎉 Gemini Pro Offer Found!</h3>
            <p style="opacity:.85;font-size:.9rem;margin-bottom:.4rem;">
                Click the link below to activate your 12-month free Gemini Advanced subscription:
            </p>
            <div class="offer-link-box">{offer_link}</div>
            <a class="open-btn" href="{safe_link}" target="_blank" rel="noopener">
                🔗 Open Activation Link ↗
            </a>
        </div>
        """, unsafe_allow_html=True)

        # copy-paste box as fallback
        st.text_input("Or copy the link:", value=offer_link, disabled=True, label_visibility="collapsed")

    # ── Failure ───────────────────────────────────────────────────────────────
    else:
        st.error(f"❌ {error or 'No active Gemini Pro offer detected.'}")

        if not error or "credential" not in error.lower():
            with st.expander("Why might there be no offer?"):
                st.markdown("""
                - **Region** — The Pixel Gemini Pro offer is primarily available in the US.
                - **Already activated** — The offer has already been redeemed on this account.
                - **Active subscription** — You already have a Gemini Pro / Advanced plan.
                - **Family group** — A family member may already have an active subscription.
                - **New account** — Very new accounts sometimes trigger rate-limiting.
                - **Device not recognised** — Google may not have recognised the Pixel profile.
                  Try clicking **Try Again** to generate a fresh device fingerprint.
                """)

    # ── Logs ─────────────────────────────────────────────────────────────────
    logs = st.session_state.get("logs", [])
    if logs:
        with st.expander("📋 Activity Log", expanded=not bool(offer_link)):
            holder = st.empty()
            _render_log_box(holder)

    # ── Device info ───────────────────────────────────────────────────────────
    if device:
        with st.expander("📱 Device Profile Used"):
            st.json({
                "model":           device.model,
                "android_version": device.android_version,
                "build_id":        device.build_id,
                "chrome_version":  device.chrome_version,
                "imei":            device.imei[:8] + "…",
                "android_id":      device.android_id[:8] + "…",
                "session_id":      device.session_id[:8] + "…",
            })

    st.divider()

    col1, col2 = st.columns(2)
    with col1:
        btn_label = "🔄 Try Again (New Device)" if not offer_link else "🔄 Check Again"
        if st.button(btn_label, use_container_width=True, type="primary" if not offer_link else "secondary"):
            st.session_state.update({
                "logs": [],
                "offer_link": None,
                "error": None,
                "device": None,
            })
            _set_stage("run")
            st.rerun()
    with col2:
        if st.button("🔒 Logout & Start Over", use_container_width=True):
            _clear_session()
            st.rerun()


# ═══════════════════════════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    # Ensure sid exists
    _sid()

    # ── Header ─────────────────────────────────────────────────────────────
    st.markdown("## 📱 Pixel Gemini Offer Finder")
    st.caption(
        "Pixel 10 Pro  ·  Android 16  ·  Google One  ·  12-Month Free Gemini Advanced"
    )

    # ── Session status pill in sidebar ─────────────────────────────────────
    with st.sidebar:
        st.markdown("### Session")
        email = st.session_state.get("email")
        if email:
            st.success(f"Signed in as **{email}**", icon="✅")
            device = st.session_state.get("device")
            if device:
                st.caption(
                    f"Device: {device.model}  \n"
                    f"Android: {device.android_version}  \n"
                    f"Chrome: {device.chrome_version}"
                )
        else:
            st.info("Not signed in", icon="🔐")
        st.divider()
        st.caption("Credentials are held **in memory only** and wiped on logout.")

    st.divider()

    # ── Stage dispatch ─────────────────────────────────────────────────────
    s = _stage()
    if s == "login":
        _render_login()
    elif s == "run":
        _render_run()
    elif s == "processing":
        _render_processing()
    elif s == "needs_2fa":
        _render_needs_2fa()
    elif s == "result":
        _render_result()
    else:
        _set_stage("login")
        st.rerun()


if __name__ == "__main__":
    main()
