"""
Google One automation — Playwright edition.

Public API identical to the original Selenium version:
    start_login(email, password, device, proxy=None)  → (session, status)
    submit_2fa_code(session, code)                    → bool
    check_offer_with_driver(session)                  → Optional[str]
    close_driver(session)                             → None
    STEALTH_AVAILABLE                                  → bool
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from typing import Any, Optional
from urllib.parse import urlparse

import config
from device_simulator import DeviceProfile, PIXEL_10_PRO_SPECS

logger = logging.getLogger(__name__)

# ── playwright-stealth (optional but recommended) ─────────────────────────────
try:
    from playwright_stealth import stealth_sync as _stealth_sync
    STEALTH_AVAILABLE = True
    logger.info("playwright-stealth loaded ✅")
except ImportError:
    STEALTH_AVAILABLE = False
    logger.warning("playwright-stealth not installed — using manual JS injection only")


# ═══════════════════════════════════════════════════════════════════════════════
# Session container
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class PlaywrightSession:
    _pw:     Any
    browser: Any
    context: Any
    page:    Any
    device:  DeviceProfile
    proxy:   Optional[str] = None

    def close(self) -> None:
        for fn, label in [
            (lambda: self.page.close() if not self.page.is_closed() else None, "page"),
            (lambda: self.context.close(), "context"),
            (lambda: self.browser.close(), "browser"),
            (lambda: self._pw.stop(),      "playwright"),
        ]:
            try:
                fn()
            except Exception as exc:
                logger.debug("Error closing %s: %s", label, exc)


class GoogleAutomationError(Exception):
    """Raised when automation encounters an unrecoverable error."""


# ═══════════════════════════════════════════════════════════════════════════════
# Session factory
# ═══════════════════════════════════════════════════════════════════════════════

def _build_session(device: DeviceProfile, proxy: Optional[str] = None) -> PlaywrightSession:
    from playwright.sync_api import sync_playwright

    pw = sync_playwright().start()

    launch_kwargs: dict = {
        "headless": True,
        "args": [
            "--no-sandbox", "--disable-dev-shm-usage", "--disable-gpu",
            "--disable-extensions", "--disable-background-networking",
            "--disable-default-apps", "--no-first-run",
            "--renderer-process-limit=2",
            "--js-flags=--max-old-space-size=512",
        ],
    }

    if proxy:
        try:
            from proxy_manager import parse_proxy_string
            pw_proxy = parse_proxy_string(proxy)
            if pw_proxy:
                launch_kwargs["proxy"] = pw_proxy
        except ImportError:
            logger.warning("proxy_manager not found — proxy skipped")

    browser = pw.chromium.launch(**launch_kwargs)

    S = PIXEL_10_PRO_SPECS
    context = browser.new_context(
        user_agent=device.user_agent,
        viewport={"width": S["width"], "height": S["height"]},
        device_scale_factor=S["pixel_ratio"],
        is_mobile=True,
        has_touch=True,
        locale=device.locale,
        timezone_id="America/Los_Angeles",
        color_scheme="dark",
        extra_http_headers={
            **device.client_hints_headers(),
            "Accept-Language": device.accept_language,
            "Accept-Encoding": "gzip, deflate, br",
        },
    )

    page = context.new_page()

    # Stealth first (generic), then Pixel-specific overrides last so our
    # WebGL vendor/renderer and navigator values always win conflicts.
    if STEALTH_AVAILABLE:
        _stealth_sync(page)
    page.add_init_script(device.navigator_overrides_js())

    return PlaywrightSession(
        _pw=pw, browser=browser, context=context, page=page,
        device=device, proxy=proxy,
    )


# ═══════════════════════════════════════════════════════════════════════════════
# Login helpers
# ═══════════════════════════════════════════════════════════════════════════════

def _safe_click(page, selectors: list[str]) -> bool:
    for sel in selectors:
        try:
            loc = page.locator(sel)
            if loc.count() > 0 and loc.first.is_visible():
                loc.first.click()
                return True
        except Exception:
            continue
    return False


def _handle_account_chooser(page, email: str) -> None:
    try:
        for loc in page.locator("[data-email]").all():
            try:
                if loc.get_attribute("data-email", timeout=500) == email:
                    loc.click()
                    return
            except Exception:
                continue
        _safe_click(page, [
            "text=/use another account/i",
            '[data-action="addaccount"]',
            'div:has-text("Use another account")',
        ])
    except Exception as exc:
        logger.debug("Account chooser skipped: %s", exc)


def _try_find_totp_input(page) -> bool:
    for sel in (
        'input[name="totpPin"]', 'input[name="idvPin"]',
        'input[aria-label*="code" i]', 'input[type="tel"][maxlength="6"]',
    ):
        try:
            if page.locator(sel).count() > 0:
                return True
        except Exception:
            pass
    return False


def _try_switch_to_totp(page) -> bool:
    for sel in (
        'text=/try another way/i', 'text=/more options/i',
        'text=/use a different method/i', '[data-action="tryanoption"]',
    ):
        try:
            loc = page.locator(sel)
            if loc.count() > 0:
                loc.first.click()
                time.sleep(1.5)
                return True
        except Exception:
            continue
    return False


def _detect_login_state(page, _depth: int = 0) -> str:
    if _depth > 4:
        return "failed"

    url = page.url
    for pat in ("myaccount.google.com", "mail.google.com", "accounts.google.com/b/"):
        if pat in url:
            return "success"
    if "accounts.google.com" not in url and url.startswith("https://"):
        return "success"

    try:
        body = page.inner_text("body", timeout=5000).lower()
    except Exception:
        body = ""

    for phrase in (
        "wrong password", "incorrect password", "couldn't find your google account",
        "couldn't sign you in", "account has been disabled",
        "this account doesn't exist", "too many failed attempts",
    ):
        if phrase in body:
            logger.warning("Login rejected: %s", phrase)
            return "failed"

    if _try_find_totp_input(page):
        logger.info("TOTP input detected")
        return "needs_totp"

    for phrase in (
        "enter a verification code", "enter the code", "enter a 6-digit",
        "2-step verification", "two-step verification", "authenticator app",
    ):
        if phrase in body and _try_find_totp_input(page):
            return "needs_totp"

    for phrase in ("check your phone", "verify it's you", "confirm it's you", "send a code"):
        if phrase in body:
            if _try_switch_to_totp(page):
                time.sleep(2)
                return _detect_login_state(page, _depth + 1)
            logger.warning("Phone challenge — cannot bypass automatically")
            return "failed"

    if "accounts.google.com" in url:
        if any(seg in url for seg in ("/signin", "/v3/signin", "/challenge")):
            logger.debug("Still on Google login page (depth %d)", _depth)
            time.sleep(2.5)
            return _detect_login_state(page, _depth + 1)

    return "failed"


def _gmail_login(session: PlaywrightSession, email: str, password: str) -> str:
    page = session.page
    T    = config.WEBDRIVER_TIMEOUT * 1000

    logger.info("Navigating to Google login page")
    try:
        page.goto(
            config.GMAIL_LOGIN_URL,
            wait_until="domcontentloaded",
            timeout=config.PAGE_LOAD_TIMEOUT * 1000,
        )
    except Exception as exc:
        raise GoogleAutomationError(f"Failed to load login page: {exc}") from exc

    time.sleep(2)

    if "oauthchooseaccount" in page.url or "/b/" in page.url:
        _handle_account_chooser(page, email)
        time.sleep(1.5)

    # ── Email ─────────────────────────────────────────────────────────────────
    email_sel = 'input[type="email"], #identifierId'
    try:
        page.wait_for_selector(email_sel, timeout=T, state="visible")
        page.fill(email_sel, "")
        page.type(email_sel, email, delay=88)
    except Exception as exc:
        logger.error("Email input not found: %s", exc)
        return "failed"

    time.sleep(0.6)
    _safe_click(page, ["#identifierNext", '[data-primary-action-label]',
                        'button:has-text("Next")', '[jsname="LgbsSe"]'])
    time.sleep(2.5)

    # ── Password ──────────────────────────────────────────────────────────────
    pw_sel = 'input[type="password"]'
    try:
        page.wait_for_selector(pw_sel, timeout=T, state="visible")
        page.fill(pw_sel, "")
        page.type(pw_sel, password, delay=92)
    except Exception as exc:
        logger.error("Password input not found: %s", exc)
        return "failed"

    time.sleep(0.6)
    _safe_click(page, ["#passwordNext", '[data-primary-action-label]',
                        'button:has-text("Next")', '[jsname="LgbsSe"]'])
    time.sleep(3.5)

    return _detect_login_state(page)


def _submit_totp_internal(session: PlaywrightSession, code: str) -> bool:
    page = session.page
    totp_sel: Optional[str] = None

    for sel in (
        'input[name="totpPin"]', 'input[name="idvPin"]',
        'input[aria-label*="code" i]', 'input[type="tel"][maxlength="6"]',
        'input[type="number"]',
    ):
        try:
            if page.locator(sel).count() > 0:
                totp_sel = sel
                break
        except Exception:
            continue

    if totp_sel is None:
        logger.error("Could not locate TOTP input field")
        return False

    try:
        page.fill(totp_sel, "")
        page.type(totp_sel, code, delay=80)
    except Exception as exc:
        logger.error("Error typing TOTP: %s", exc)
        return False

    time.sleep(0.5)
    _safe_click(page, [
        "#totpNext", 'button[jsname="LgbsSe"]', '[data-action="verify"]',
        'button:has-text("Next")', 'button:has-text("Verify")', 'button[type="submit"]',
    ])
    time.sleep(2.5)

    parsed = urlparse(page.url)
    if parsed.hostname == "accounts.google.com" and "challenge" in (parsed.path or ""):
        logger.warning("Still on challenge page — TOTP may be wrong")
        return False

    logger.info("TOTP accepted")
    return True


# ═══════════════════════════════════════════════════════════════════════════════
# Offer detection  (logic identical to original; only Selenium API replaced)
# ═══════════════════════════════════════════════════════════════════════════════

def _is_valid_offer_url(href: str) -> bool:
    if not href:
        return False
    whitelist = config.OFFER_DOMAIN_WHITELIST
    if not whitelist:
        return bool(href)
    try:
        hostname = urlparse(href).hostname or ""
        return any(hostname == d or hostname.endswith("." + d) for d in whitelist)
    except Exception:
        return False


def _is_correct_offer_url(url: str) -> bool:
    return bool(url) and "partner-eft-onboard" in url


def _extract_payment_link(page) -> Optional[str]:
    all_links = page.locator("a").all()

    # Strategy 0: click LOCKED benefit link
    for link in all_links:
        try:
            href = link.get_attribute("href") or ""
            if "LOCKED" in href and "BARD_ADVANCED" in href:
                logger.info("Found LOCKED benefit link: %s", href)
                old_url = page.url
                link.dispatch_event("click")
                time.sleep(5)
                current_url = page.url
                logger.info("After LOCKED click → %s", current_url)

                if _is_correct_offer_url(current_url):
                    return current_url
                if "LOCKED" in current_url:
                    logger.warning("URL still LOCKED — device does not qualify")
                    return None
                if current_url != old_url:
                    for nl in page.locator("a").all():
                        try:
                            nh = nl.get_attribute("href") or ""
                            if _is_correct_offer_url(nh):
                                return nh
                        except Exception:
                            continue
                    if _is_correct_offer_url(current_url):
                        return current_url
                    logger.warning("Navigated to %s but no offer link found", current_url)
                else:
                    logger.warning("LOCKED click didn't navigate — device may not qualify")
                return None
        except Exception as exc:
            logger.warning("Error clicking LOCKED link: %s", exc)
            return None

    # Strategy 1: direct partner-eft-onboard scan
    for link in all_links:
        try:
            href = link.get_attribute("href") or ""
            if _is_correct_offer_url(href):
                return href
        except Exception:
            continue

    # Strategy 2: anchor text / aria-label
    keywords = config.GEMINI_OFFER_KEYWORDS
    for link in all_links:
        try:
            text = (
                (link.inner_text() or "") + " " + (link.get_attribute("aria-label") or "")
            ).lower()
            href = link.get_attribute("href") or ""
            if "LOCKED" in href:
                continue
            if any(kw in text for kw in keywords) and _is_correct_offer_url(href):
                return href
        except Exception:
            continue

    # Strategy 3: broad scan
    for link in all_links:
        try:
            href = link.get_attribute("href") or ""
            if _is_correct_offer_url(href):
                return href
        except Exception:
            continue

    return None


def _navigate_google_one(session: PlaywrightSession) -> Optional[str]:
    page = session.page
    for url in (config.GOOGLE_ONE_URL, config.GOOGLE_ONE_OFFERS_URL):
        try:
            logger.info("Navigating to %s", url)
            page.goto(url, wait_until="domcontentloaded", timeout=config.PAGE_LOAD_TIMEOUT * 1000)
            time.sleep(3)

            for sel in ('[aria-label="Accept all"]', 'button[jsname="higCR"]',
                        '[data-action="accept"]', 'button:has-text("Accept all")'):
                try:
                    loc = page.locator(sel)
                    if loc.count() > 0 and loc.first.is_visible():
                        loc.first.click()
                        time.sleep(1)
                        break
                except Exception:
                    pass

            link = _extract_payment_link(page)
            if link is not None:
                return link
        except Exception as exc:
            logger.warning("Error accessing %s: %s", url, exc)

    return None


# ═══════════════════════════════════════════════════════════════════════════════
# Public API
# ═══════════════════════════════════════════════════════════════════════════════

def start_login(
    email: str,
    password: str,
    device: DeviceProfile,
    proxy: Optional[str] = None,
) -> tuple:
    try:
        session = _build_session(device, proxy=proxy)
    except Exception as exc:
        raise GoogleAutomationError(f"Browser launch failed: {exc}") from exc
    try:
        status = _gmail_login(session, email, password)
        return session, status
    except GoogleAutomationError:
        session.close()
        raise
    except Exception as exc:
        session.close()
        raise GoogleAutomationError(f"Login error: {exc}") from exc


def submit_2fa_code(session, code: str) -> bool:
    try:
        return _submit_totp_internal(session, code)
    except Exception as exc:
        logger.error("submit_2fa_code error: %s", exc)
        return False


def check_offer_with_driver(session) -> Optional[str]:
    try:
        return _navigate_google_one(session)
    except Exception as exc:
        logger.error("check_offer_with_driver error: %s", exc)
        return None


def close_driver(session) -> None:
    if session is None:
        return
    try:
        if hasattr(session, "close"):
            session.close()
        elif hasattr(session, "quit"):
            session.quit()
    except Exception as exc:
        logger.debug("close_driver: %s", exc)
