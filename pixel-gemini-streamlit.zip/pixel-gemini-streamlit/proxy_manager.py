"""
Proxy management: parse proxy strings, validate connectivity + US geolocation,
and pick a random working proxy from the pool.

Supported formats:
    http://ip:port
    http://ip:port|user:pass
    socks5://ip:port
    socks5://ip:port|user:pass
    ip:port              ← assumed http://
"""

from __future__ import annotations

import logging
import random
import re
from typing import Optional
from urllib.parse import urlparse

import requests

logger = logging.getLogger(__name__)

_CHECK_URL   = "http://ip-api.com/json/?fields=status,country,countryCode,regionName,city,isp,hosting,proxy,query"
_CHECK_TIMEOUT = 12   # seconds per proxy test


# ═══════════════════════════════════════════════════════════════════════════════
# Parsing
# ═══════════════════════════════════════════════════════════════════════════════

def parse_proxy_string(s: str) -> Optional[dict]:
    """
    Convert a proxy line to a Playwright-compatible proxy config dict.

    Returns None for blank / comment lines.
    Returned dict always has 'server'; may also have 'username', 'password'.
    """
    s = s.strip()
    if not s or s.startswith("#"):
        return None

    username = password = None
    if "|" in s:
        addr, cred = s.split("|", 1)
        if ":" in cred:
            username, password = cred.split(":", 1)
        s = addr.strip()
    else:
        s = s

    # Normalise socks:// → socks5://
    if re.match(r"^socks://", s, re.IGNORECASE):
        s = "socks5://" + s[7:]

    # Add scheme if missing
    if not re.match(r"^[a-z0-9+\-]+://", s, re.IGNORECASE):
        s = "http://" + s

    result: dict = {"server": s}
    if username:
        result["username"] = username.strip()
    if password:
        result["password"] = password.strip()
    return result


def _to_requests_proxies(proxy_str: str) -> dict:
    """Convert a raw proxy string to a `requests`-style proxy dict."""
    cfg = parse_proxy_string(proxy_str)
    if not cfg:
        return {}
    server = cfg["server"]
    if "username" in cfg:
        parsed = urlparse(server)
        auth = f"{cfg['username']}:{cfg.get('password', '')}@"
        server = parsed._replace(netloc=auth + parsed.netloc).geturl()
    return {"http": server, "https": server}


def parse_proxy_list(raw: str) -> list[str]:
    """Split a newline-separated block of proxy strings into a clean list."""
    out: list[str] = []
    for line in raw.splitlines():
        line = line.strip()
        if line and not line.startswith("#"):
            out.append(line)
    return out


# ═══════════════════════════════════════════════════════════════════════════════
# Validation
# ═══════════════════════════════════════════════════════════════════════════════

def check_proxy(proxy_str: str) -> tuple[bool, bool, str, dict]:
    """
    Test a proxy via ip-api.com (free, no API key required).

    Returns:
        alive   – True if the proxy is reachable
        is_us   – True if the exit IP geolocates to the United States
        ip      – detected public IP string
        info    – raw ip-api.com JSON dict (empty on network failure)
    """
    proxies = _to_requests_proxies(proxy_str)
    try:
        resp = requests.get(
            _CHECK_URL,
            proxies=proxies,
            timeout=_CHECK_TIMEOUT,
        )
        data = resp.json()
    except Exception as exc:
        logger.debug("Proxy %s unreachable: %s", proxy_str[:40], exc)
        return False, False, "", {}

    if data.get("status") != "success":
        return True, False, "", data

    is_us = data.get("countryCode", "") == "US"
    ip    = data.get("query", "")
    return True, is_us, ip, data


# ═══════════════════════════════════════════════════════════════════════════════
# Selection
# ═══════════════════════════════════════════════════════════════════════════════

def select_valid_proxy(
    proxy_list: list[str],
    log_cb=None,
    max_tries: int = 10,
) -> tuple[Optional[str], dict]:
    """
    Randomly pick and test proxies until a live US proxy is found.

    Dead or non-US proxies are **removed from proxy_list in-place**.
    Returns (proxy_str, ip_info_dict) or (None, {}) if none qualify.
    """
    if not proxy_list:
        return None, {}

    candidates = random.sample(proxy_list, min(len(proxy_list), max_tries))

    for proxy in candidates:
        short = proxy[:50]
        if log_cb:
            log_cb(f"🌐 Testing proxy {short}…")

        alive, is_us, ip, info = check_proxy(proxy)

        if not alive:
            if log_cb:
                log_cb("  ❌ Dead — removed from pool")
            if proxy in proxy_list:
                proxy_list.remove(proxy)
            continue

        if not is_us:
            country = info.get("country", info.get("countryCode", "?"))
            if log_cb:
                log_cb(f"  ❌ Not US ({country}, {ip}) — removed from pool")
            if proxy in proxy_list:
                proxy_list.remove(proxy)
            continue

        city    = info.get("city", "?")
        region  = info.get("regionName", "?")
        isp     = info.get("isp", "?")
        ptype   = "🏢 Datacenter" if info.get("hosting") else "🏠 Residential"
        if log_cb:
            log_cb(f"  ✅ {ip} — {city}, {region} US — {ptype} — {isp}")

        return proxy, info

    return None, {}
