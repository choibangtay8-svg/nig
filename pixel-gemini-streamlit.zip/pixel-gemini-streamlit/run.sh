#!/usr/bin/env bash
# Quick launcher for Pixel Gemini Offer Finder (Streamlit)
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo " 📱 Pixel Gemini Offer Finder — Streamlit UI"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# ── Check Python ──────────────────────────────────────────────────────────────
if ! command -v python3 &>/dev/null; then
    echo "❌ python3 not found. Please install Python 3.10+."
    exit 1
fi

PYTHON_VER=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
echo "✅ Python $PYTHON_VER detected"

# ── Check Chromium ────────────────────────────────────────────────────────────
CHROME_BIN=""
for bin in chromium chromium-browser google-chrome; do
    if command -v "$bin" &>/dev/null; then
        CHROME_BIN="$bin"
        break
    fi
done
if [ -z "$CHROME_BIN" ]; then
    echo ""
    echo "⚠️  Chromium not found. Install it first:"
    echo "   Ubuntu/Debian:  sudo apt-get install -y chromium-browser chromium-chromedriver"
    echo "   Arch:           sudo pacman -S chromium"
    echo "   macOS:          brew install --cask chromium"
    echo ""
fi

# ── Install Python deps ───────────────────────────────────────────────────────
echo ""
echo "📦 Installing / verifying Python dependencies…"
pip3 install -q -r requirements.txt

# ── Launch ────────────────────────────────────────────────────────────────────
echo ""
echo "🚀 Starting Streamlit app…"
echo "   Open → http://localhost:8501"
echo ""
streamlit run app.py \
    --server.headless true \
    --server.port 8501 \
    --browser.gatherUsageStats false
