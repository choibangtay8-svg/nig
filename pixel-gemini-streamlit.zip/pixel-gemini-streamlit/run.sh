#!/usr/bin/env bash
set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo " 📱 Pixel Gemini Finder  —  Playwright edition"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Python check
if ! command -v python3 &>/dev/null; then
  echo "❌ python3 not found. Install Python 3.10+."
  exit 1
fi
echo "✅ Python $(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')"

# Install Python deps
echo ""
echo "📦 Installing dependencies…"
pip3 install -q -r requirements.txt

# Install Playwright Chromium if not already present
echo "🌐 Checking Playwright Chromium…"
python3 -c "
from playwright.sync_api import sync_playwright
try:
    with sync_playwright() as p:
        p.chromium.launch(headless=True).close()
    print('✅ Playwright Chromium OK')
except Exception:
    import subprocess, sys
    print('📥 Installing Chromium…')
    subprocess.run([sys.executable, '-m', 'playwright', 'install', 'chromium', '--with-deps'], check=True)
"

echo ""
echo "🚀 Starting Streamlit at http://localhost:8501"
echo ""
streamlit run app.py \
  --server.headless true \
  --server.port 8501 \
  --browser.gatherUsageStats false
